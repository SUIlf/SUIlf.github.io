# RandMatrixMatlab
Simple MATLAB code for randomized matrix computation.

First run ``setup''.

The detailed descriptions are in the article:
"A Practical Guide to Randomized Matrix Computations with MATLAB Implementations"
http://arxiv.org/abs/1505.07570


